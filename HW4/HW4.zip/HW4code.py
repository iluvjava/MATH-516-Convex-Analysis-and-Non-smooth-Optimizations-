class LogisticRegressionOracle: 
    def __init__():
        pass

    
class GradientDescendOptimizer: 
    def __init__(): 
        pass


class AcceleratedGradientDescendOptimizer:
    def __init__():
        pass


if __name__ == "__main__":

    pass